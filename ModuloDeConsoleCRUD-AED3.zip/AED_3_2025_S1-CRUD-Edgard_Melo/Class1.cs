﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AED_3_2025_S1_CRUD_Edgard_Melo
{
    internal class Class1
    {
    }
}
