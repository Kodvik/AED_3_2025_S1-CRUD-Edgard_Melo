﻿public interface IEntidade
{
    int UID { get; set; }
}